

<!DOCTYPE html>
<html lang="en-US">
   
<head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="description" content="Çok ucuz ve güvenilir CS:GO hesap sağlayıcısı, birbirinden farklı hesaplara hemen sende göz at.">
      <meta name="keyword" content="csgo prime, cs go prime, csgo prime satın al, oyun satıl al, ucuza prime satın al, cs go prime satın al, csgo prime satın al, csgo ucuza prime, cs go prime status satın al, csgo prime status satın al, csgo hesap satın al, cs go hesap satın al, cs go global hesap, csgo global hesap, csgo prime hilesi, cs go prime hilesi">
      <meta name="author" content="HesapPazarim">
      <!-- Title -->
      <title>Hesap Pazarım | CS:GO Prime Satın Al</title>
      <!-- Favicon -->
      <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon/favicon-32x32.png">
      <!--Bootstrap css-->
      <link rel="stylesheet" href="assets/css/bootstrap.css">
      <!--Font Awesome css-->
      <link rel="stylesheet" href="assets/css/font-awesome.min.css">
      <!--Magnific css-->
      <link rel="stylesheet" href="assets/css/magnific-popup.css">
      <!--Owl-Carousel css-->
      <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
      <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
      <!--NoUiSlider css-->
      <link rel="stylesheet" href="assets/css/nouislider.min.css">
      <!--Animate css-->
      <link rel="stylesheet" href="assets/css/animate.min.css">
      <!--Site Main Style css-->
      <link rel="stylesheet" href="assets/css/style.css">
      <!--Responsive css-->
      <link rel="stylesheet" href="assets/css/responsive.css">
   </head>
   <body>
       
       
 
       
       
      <!-- Header Area Start -->
      <nav class="fag-header navbar navbar-expand-lg">
         <div class="container">
            <a class="navbar-brand" href="index.html"><img src="assets/img/logo.png" alt="site logo" /></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="menu-toggle"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
               
               <ul class="header_menu  mr-auto">
                  <li class="nav-item active">
                     <a href="index.php" class="nav-link">ANA SAYFA</a>
                     
                     <li class="nav-item active">
                        <a href="#satinal" class="nav-link">HESAP SATIN AL</a>

                        <li class="nav-item active">
                           <a href="#iletisim" class="nav-link">İLETİŞİM</a>
            
                  <li class="nav-item">
                     <a href="sozlesme.php" class="nav-link">KULLANICI SÖZLEŞMESİ</a>
                  </li>
              
         </div>
      </nav>
      <!-- Header Area End -->
       
       
      <!-- Slider Area Start -->
      <section class="slider-area">
         <div class="fag-slide owl-carousel">
            <div class="fag-main-slide slide-1">
               <div class="fag-main-caption">
                  <div class="fag-caption-cell">
                     <div class="container">
                        <div class="row">
                           <div class="col-12">
                              <div class="slider-text">
                                 <h3>Hesap Pazarım</h3>
                                 <h2>Tek bizim değil, hepimizin pazarı.</h2>
                                  <a class="fag-btn-outline" href=" #satinal"><span class="fa fa-play"></span>Sende Satın Al</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
           
      </section>
      <!-- Slider Area End -->
       
       
       
      <!-- Games Area Strat -->
      <section id="satinal" class="fag-games-area section_140">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <div class="site-heading">
                     <h2 class="heading_animation">HESAP <span>SATIN AL</span></h2>
                     <p>Çok değerli hesapları çok ucuza al!</p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-12">
                  <div class="games-masonary">
                     <div class="projectFilter project-btn">
                        <ul>
                           <li><a href="#" data-filter="*" class="current">Tümü</a></li>
                           <li><a href="#" data-filter=".mobile">CS:GO Ürünleri</a></li>
                           <li><a href="#" data-filter=".desktop">Minecraft Ürünleri</a></li>
                        </ul>
                     </div>
                     <div class="clearfix gamesContainer">
                        <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/silver.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                    
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime Silver Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>69.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->
                        <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/nova.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                    
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime Nova Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>79.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->
                        <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/keles.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                   
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime MG Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>89.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->
                        <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/lem.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                    
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime LEM Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>104.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->
                        <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/global.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                              
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime Global Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>159.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->
                        <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/1medal.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                   
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime 1 Madalyalı Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>84.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->
                        <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/2medal.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                  
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="">CS:GO Prime 2 Madalyalı Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>119.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->
                        <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/3medal.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                   
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime 3 Madalyalı Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>129.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                         <!-- end game item -->
                         <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/4medal.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                   
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime 4 Madalyalı Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>149.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                         <!-- end game item -->
                         <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/5medal.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                   
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime 5 Madalyalı Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>179.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                         <!-- end game item -->
                         <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/6medal.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                                  
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">CS:GO Prime 6 Madalyalı Hesap</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>209.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                         <!-- end game item -->
                         <div class="games-item mobile">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/prime.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    <a class="popup-youtube" href="https://www.youtube.com/watch?v=3SAuuHCOkyI">
                           
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="">CS:GO Prime Hesap Satın Al</a></h3>
                                 <p class="game-meta">•Oyunun kalitesini belirle!</p>
                                 <p class="game-meta">•Satın alırken ad soyad kısmına kart sahibinin adını soyadını yazın. (Aksi takdirde ödemeniz kabul edilmez)</p>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>69.99TL</h4>
                                       <p class="off"></p>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->
                        <div class="games-item desktop">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/demir.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">Minecraft Demir Premium</a></h3>
                                 <p class="game-meta">Bilgileri değiştirilemez.</p>
                                 <div class="game-rating">
                                 </div>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>6.99TL</h4>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">SATIN AL</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->
                        <div class="games-item desktop">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/altin.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">Minecraft Altın Premium</a></h3>
                                 <p class="game-meta">İsim, cilt ve şifre değiştirilebilir.</p>
                                 <div class="game-rating">
                                 </div>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>9.99TL</h4>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item --> 
                        <div class="games-item desktop">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/elmas.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">Minecraft Elmas Premium</a></h3>
                                 <p class="game-meta">Tüm bilgileri değiştirilir.</p>
                                 <div class="game-rating">
                                 </div>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>79.99TL</h4>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın Al</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->        
                        <div class="games-item desktop">
                           <div class="games-single-item img-contain-isotope">
                              <div class="games-thumb">
                                 <div class="games-thumb-image">
                                    <a href="#">
                                    <img src="assets/img/cape.png" alt="games" />
                                    </a>
                                 </div>
                                 <div class="game-overlay">
                                    </a>
                                 </div>
                              </div>
                              <div class="games-desc">
                                 <h3><a href="#">Minecraft Cape</a></h3>
                                 <p class="game-meta">Oyunun Kalitesini Belirle!</p>
                                 <div class="game-rating">
                                 </div>
                                 <div class="game-action">
                                    <div class="game-price">
                                       <h4>44.99TL</h4>
                                    </div>
                                    <div class="game-buy">
                                       <a href="/odeme/" class="fag-btn-outline">Satın AL</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end game item -->                         
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Games Area End -->
       
       
     
       
       

       
       
      <!-- Footer Area Start -->


         </div>
         <section id="iletisim" class="fag-games-area section_140">
         <div class="footer-bottom">
            <div class="container">
               <div class="row">
                  <div class="col-12">
                     <div class="footer-bottom-inn">
                        <div class="footer-logo">
                           <a href="index.html">
                           <img src="assets/img/logo.png" alt="site logo" />
                           </a>
                        </div>
                        <div class="footer-social">
                           <ul>
                              <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                              <li><a href="https://instagram.com/hesappazarim"><span class="fa fa-instagram"></span></a></li>
                              <li><a href="#"><span class="fa fa-youtube"></span></a></li>
                              <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                              <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                           </ul>
                        </div>
                        <div class="copyright">
                           <p>&copy; Copyrights 2020 HesapPazarım - Tüm Hakları Saklıdır</p>
                           <p> İletişim; <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="8ce4e9ffedfcfcedf6edfee5e1ccebe1ede5e0a2efe3e1">[email&#160;protected]</a></p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- Footer Area End -->
       
       
      <!--Jquery js-->
      <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script>
      <!-- Popper JS -->
      <script src="assets/js/popper.min.js"></script>
      <!--Bootstrap js-->
      <script src="assets/js/bootstrap.min.js"></script>
      <!--Owl-Carousel js-->
      <script src="assets/js/owl.carousel.min.js"></script>
      <!--Magnific js-->
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <!--wNumb js-->
      <script src="assets/js/wNumb.js"></script>
      <!--NoUiSlider js-->
      <script src="assets/js/nouislider.min.js"></script>
      <!-- Isotop Js -->
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/custom-isotop.js"></script>
      <!-- Counter JS -->
      <script src="assets/js/jquery.counterup.min.js"></script>
      <!-- Way Points JS -->
      <script src="assets/js/waypoints-min.js"></script>
      <!-- Custom Clock JS -->
      <script src="assets/js/clock-custom.js"></script>
      <!--Main js-->
      <script src="assets/js/main.js"></script>
   </body>


</html>

