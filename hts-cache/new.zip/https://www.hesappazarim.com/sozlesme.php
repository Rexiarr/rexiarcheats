<!DOCTYPE html>
<html lang="en-US">
   
<!-- Mirrored from themescare.com/demos/faf/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 Jan 2021 11:01:40 GMT -->
<head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="description" content="Çok ucuz ve güvenilir CS:GO hesap sağlayıcısı, birbirinden farklı hesaplara hemen sende göz at.">
      <meta name="keyword" content="csgo prime, cs go prime, csgo prime satın al, oyun satıl al, ucuza prime satın al, cs go prime satın al, csgo prime satın al, csgo ucuza prime, cs go prime status satın al, csgo prime status satın al, csgo hesap satın al, cs go hesap satın al, cs go global hesap, csgo global hesap, csgo prime hilesi, cs go prime hilesi">
      <meta name="author" content="HesapPazarim">
      <!-- Title -->
      <title>Hesap Pazarım | Oyun Satın Al</title>
      <!-- Favicon -->
      <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon/favicon-32x32.png">
      <!--Bootstrap css-->
      <link rel="stylesheet" href="assets/css/bootstrap.css">
      <!--Font Awesome css-->
      <link rel="stylesheet" href="assets/css/font-awesome.min.css">
      <!--Magnific css-->
      <link rel="stylesheet" href="assets/css/magnific-popup.css">
      <!--Owl-Carousel css-->
      <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
      <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
      <!--NoUiSlider css-->
      <link rel="stylesheet" href="assets/css/nouislider.min.css">
      <!--Animate css-->
      <link rel="stylesheet" href="assets/css/animate.min.css">
      <!--Site Main Style css-->
      <link rel="stylesheet" href="assets/css/style.css">
      <!--Responsive css-->
      <link rel="stylesheet" href="assets/css/responsive.css">
   </head>
   <body>
       
       
 
       
       
      <!-- Header Area Start -->
      <nav class="fag-header navbar navbar-expand-lg">
         <div class="container">
            <a class="navbar-brand" href="index.html"><img src="assets/img/logo.png" alt="site logo" /></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="menu-toggle"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
               
               <ul class="header_menu  mr-auto">
                  <li class="nav-item active">
                     <a href="index.php" class="nav-link">ANA SAYFA</a>
                     
                     <li class="nav-item active">
                        <a href="#satinal" class="nav-link">HESAP SATIN AL</a>

                        <li class="nav-item active">
                           <a href="#iletisim" class="nav-link">İLETİŞİM</a>
            
                  <li class="nav-item">
                     <a href="contact.html" class="nav-link">KULLANICI SÖZLEŞMESİ</a>
                  </li>
              
         </div>
      </nav>
       
       
      <!-- Contact Form Start -->
      <section class="fag-contact-form section_100">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <div class="site-heading">
                     <h2 class="heading_animation">Kullanıcı<span>Sözleşmesi</span></h2>
                     
                  </div>

               </div>
   
           </div>
   
           <div class="row">
               
               <section class="blog-content each-element" style="padding-top: 40px;">
   <div class="container">
   
   <h4>1. SÖZLEŞMENİN TARAFLARI</h4>
   <p>
   Bir tarafta hesappazarim.com (Bundan sonra "Şahıs-ŞİRKETİ" olarak sayılacaktır) ile diğer tarafta -Şahıs-ŞİRKETİ TARAFINDAN İŞLETİLEN hesappazarim.com(Bundan sonra "İnternet Sitesi" olarak anılacaktır) internet adresinde- ürün alımı yapmak üzere "ALICI KULLANICI" veya ürün satışı yapmak için aracılık yapan "BAYİ" tüm özel ve tüzel kişiler arasında aşağıdaki şartlarla işbu kullanıcı sözleşmesi imzalanmıştır. Bütün "ALICI KULLANICILAR" ve "BAYİLER", "İNTERNET SİTESİNE" ÜYE OLMAKLA BU SÖZLEŞMENIN BÜTÜN HÜKÜMLERİNİ PEŞİNEN ve GAYRİKABİLİ RÜCU OLARAK ONAYLADIKLARINI KABUL EDERLER. 
   </p>
   <h4>2. KULLANIM KOŞULLARI</h4>
   <p>
   "ALICI KULLANICILAR" a ilişkin ayrıntılı düzenlemeler aşağıda yer almaktadır. ALICI KULLANICILAR", hesappazarim.com"İnternet Sitesi" üzerinden alım yaparken  "ŞİRKET" ile yalnızca ürün satın alma konusunda anlaşmış bulunan kullanıcılardır. <br> <br>
   "ALICI KULLANICILAR" ın "İnternet Sitesi" nde teshir edilen ve satın alacakları ürünler "İnternet Sitesi" nde "ŞİRKET" stoklarıyla, "ŞİRKET" in teknolojik ve sınaî imkânlarıyla sınırlıdır. Siparişler, hesappazarim.com"İnternet Sitesi" nde görünen fiziki - görsel durumlarından farklılıklar gösterebilir, siparişler ŞİRKET stoklarıyla sınırlıdır.
   <br> <br>
   "ALICI KULLANICILAR" hesappazarim.com"İnternet Sitesi" nin adı başta olmak üzere, bu sitede teşhir edilen ürünlerin, yazı, resim ve tasarımların ve "İnternet Sitesi" nin işleyiş sisteminin bütün haklarının hesappazarim.com ait olduğunu, yukarıda zikredilenlerle birlikte, "ŞİRKET" e ait olan hiçbir hak konusunun izinsiz kullanılmayacağını peşinen kabul etmektedir.
   <br> <br>
   Bu hak veya hakların izinsiz kullanımı halinde "ŞİRKET" koşulsuz/şartsız alım yapan tarafın alımını iptal edebilir.
   <br> <br>
   "ALICI KULLANICILAR" hesappazarim.com"İnternet Sitesi" ne sipariş vererek, sipariş verdiği ürünün temel niteliklerini, satış fiyatını, ödeme şeklini ve teslimata ilişkin ön bilgileri peşinen kabul ve teyit etmektedir.
   <br> <br>
   "ALICI KULLANICILAR" hesappazarim.com"İnternet Sitesi" den kredi kartı ile sipariş verebilirler. Siparişin "ŞİRKET" tarafından değerlendirilmeye alınma zamanı siparişin verilme zamanı değil, ürün bedelinin tüm vergiler toplamının kredi kartından tahsilâtının yapıldığı andır. 
   <br> <br>
   
   Mesafeli Sözleşmeler Uygulama Usul ve Esasları Hakkında Yönetmelik Madde 8 / IV uyarınca hesappazarim.com"İnternet Sitesi" nden sipariş veren "ALICI KULLANICILAR" ın satın aldıkları ürün için vazgeçme hakları bulunmamaktadır. "ALICI KULLANICILAR" ın siparişleri  kendilerine mail yolu ile teslim edilir aksi teslimler de oluşan sorunlardan "ŞİRKET" Sorumlu değildir.
   
   
   </p>
   <h4>
   3. FİYATLANDIRMA
   </h4>
   <p>
   hesappazarim.com önceden haber vermeksizin, teşhirde bulunan ürünlerinde ve bu ürünlerin fiyatlarında değişiklik yapma hakkına sahiptir. 
   </p>
   <h4>4. TESLİMAT KOŞULLARI</h4>
   <p>
   Siparişler en geç 2 gün içersinde teslim edilir ancak stok olmadığı zaman bu süre uzayabilir. 
   </p>
   <h4>5. SİPARİŞ İPTAL KOŞULLARI
   </h4>
   <p>
   "ALICI KULLANICILAR", hesappazarim.com üzerinde satılan herhangi bir ürün de sorun çıkmasına karşın iptal etme hakkı hesappazarim.com uygun görmediği sürece yoktur.
   </p>
   <h4>6. ÜRÜN İADE</h4>
   <p>
   "ALICI KULLANICILAR" ın şifreli ürünlerin, Mesafeli Sözleşmeler Uygulama Usul ve Esasları Hakkında Yönetmelik Madde 8 / IV uyarınca hesappazarim.com "İnternet Sitesi" Üzerinden sipariş veren "ALICI KULLANICILAR" ın satın aldıkları mallarda cayma hakları bulunmamaktadır. 
   </p>
   <h4>7. GARANTİ</h4>
   <p>"ALICI KULLANICILAR" ın hesappazarim.com üzerinden almış olduğu ürünlerin garantilerini ve değişim haklarını hesappazarim.com tek taraflı olarak fesh etme hakkına sahiptir. Hesapların garantisi yoktur sonradan hesaplar gidebilir. 
   </p>
   <h4>8. FESİH</h4>
   <p>
   "ŞİRKET" sözleşmeyi her zaman sebep göstermeksizin tek taraflı olarak fesih etme hakkına sahiptir. hesappazarim.com adresini ziyaret eden ve/veya alışveriş yapan üye veya üye harici tüm kullanıcılar işbu sözleşmeyi kabul etmiş sayılır. 
   </p>
   <h4>9.DEĞİŞİM</h4>
   <p>
   Ürünlerinizde sonradan oluşan bir sorun var ise değişim yapılmamaktadır. Satın aldığınız an hesap bilgileri yanlış ise SHOPINEXT üzerinden alım saatinize bakılıp bir kereye mahsus olmak koşulu ile hesap verilmektedir.
   <h4>10.İADE VE İPTAL KOŞULLARI</h4>
   <p>
   İade ve iptal koşullarımız Satış/Kullanıcı Sözleşmemizde belirtilmiştir.
   </p>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <br>
   <h4></h4>Copyright HesapPazarım © 2018-2020.Her hakkı saklıdır.<h4></h4>
   </div>
   </div>
   </div>
   </section>
   
               </div>
            </div>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Contact Form End -->
       
       
      <!-- Footer Area Start -->


         </div>
         <section id="iletisim" class="fag-games-area section_140">
         <div class="footer-bottom">
            <div class="container">
               <div class="row">
                  <div class="col-12">
                     <div class="footer-bottom-inn">
                        <div class="footer-logo">
                           <a href="index-2.html">
                           <img src="assets/img/logo.png" alt="site logo" />
                           </a>
                        </div>
                        <div class="footer-social">
                           <ul>
                              <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                              <li><a href="https://instagram.com/hesap.pazarim"><span class="fa fa-instagram"></span></a></li>
                              <li><a href="#"><span class="fa fa-youtube"></span></a></li>
                              <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                              <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                           </ul>
                        </div>
                        <div class="copyright">
                           <p>&copy; Copyrights 2020 HesapPazarım - Tüm Hakları Saklıdır</p>
                           <p> İletişim; <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="e88a81848f81a8808d9b8998988992899a8185c68b8785">[email&#160;protected]</a></p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- Footer Area End -->
       
       
      <!--Jquery js-->
      <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script>
      <!-- Popper JS -->
      <script src="assets/js/popper.min.js"></script>
      <!--Bootstrap js-->
      <script src="assets/js/bootstrap.min.js"></script>
      <!--Owl-Carousel js-->
      <script src="assets/js/owl.carousel.min.js"></script>
      <!--Magnific js-->
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <!--wNumb js-->
      <script src="assets/js/wNumb.js"></script>
      <!--NoUiSlider js-->
      <script src="assets/js/nouislider.min.js"></script>
      <!-- Isotop Js -->
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/custom-isotop.js"></script>
      <!-- Counter JS -->
      <script src="assets/js/jquery.counterup.min.js"></script>
      <!-- Way Points JS -->
      <script src="assets/js/waypoints-min.js"></script>
      <!--Main js-->
      <script src="assets/js/main.js"></script>
   </body>

<!-- Mirrored from themescare.com/demos/faf/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 Jan 2021 11:05:56 GMT -->
</html>

